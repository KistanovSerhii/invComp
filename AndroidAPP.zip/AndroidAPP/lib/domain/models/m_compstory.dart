class ModelCompStory {
  String id;
  String name;
  String type;
  List<dynamic> story;

  ModelCompStory(
      {required this.id,
      required this.name,
      required this.type,
      required this.story});
}
