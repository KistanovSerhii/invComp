import 'package:devices_storage/domain/models/m_compstory.dart';

abstract class CompInvBase1CSourceContract {
  Future<ModelCompStory> getDeviceHistoryById(
      {required int id, required String type});
}
