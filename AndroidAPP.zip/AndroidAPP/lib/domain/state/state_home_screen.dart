import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:devices_storage/domain/models/m_compstory.dart';

import '../contracts/c_compinvbase1csource.dart';

// notifyListeners() - вызывает обновление view
class StateHomeScreen extends ChangeNotifier {
  StateHomeScreen({required this.compInvBase1C});

  final CompInvBase1CSourceContract compInvBase1C;

  ModelCompStory? compStory;
  bool isLoading = false;

  Future<void> getDeviceHistoryById(
      {required int id, required String type}) async {
    isLoading = true;
    notifyListeners();
    compStory = await compInvBase1C.getDeviceHistoryById(id: id, type: type);
    isLoading = false;
    notifyListeners();
  }
}
