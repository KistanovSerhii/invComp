import 'package:devices_storage/data/api/a_iis150compinvbase.dart';
import 'package:devices_storage/domain/models/m_compstory.dart';
import 'package:devices_storage/domain/contracts/c_compinvbase1csource.dart';

class RepositoryIIS150CompInvBase implements CompInvBase1CSourceContract {
  final ApiIIS150CompInvBase _iis150compinvbaseApi;

  RepositoryIIS150CompInvBase(this._iis150compinvbaseApi);

  @override
  Future<ModelCompStory> getDeviceHistoryById(
      {required int id, required String type}) {
    return _iis150compinvbaseApi.getDeviceHistoryById(id: id, type: type);
  }
}
