// "На рисунку это желание-заказ клиента (например: три порции яблочного сока)"
class ParamIIS150CompInvBaseCompStory {
  final int id;
  final String type;

  ParamIIS150CompInvBaseCompStory({required this.id, required this.type});

  Map<String, dynamic> toApi() {
    return {'id': id, 'type': type};
  }
}
