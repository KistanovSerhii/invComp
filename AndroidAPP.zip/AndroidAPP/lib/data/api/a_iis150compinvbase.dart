import 'package:devices_storage/domain/models/m_compstory.dart';
import 'package:devices_storage/data/api/services/s_iis150compinvbase.dart';
import 'package:devices_storage/data/api/services_parameters/s_p_iis150compinvbasecompstory.dart';
import 'package:devices_storage/data/api/type_converters/t_c_iis150compinvbasecompstory.dart';

class ApiIIS150CompInvBase {
  final ServiceIIS150CompInvBase _iis150CompInvBaseService;

  ApiIIS150CompInvBase(this._iis150CompInvBaseService);

  Future<ModelCompStory> getDeviceHistoryById(
      {required int id, required String type}) async {
    // ВАЖНО проверять наличие интернета иначе валит ошибку в которой пользователю не разобраться!
    final parameters = ParamIIS150CompInvBaseCompStory(id: id, type: type);
    final result =
        await _iis150CompInvBaseService.getDeviceHistoryById(parameters);

    return TypeConverterIIS150CompInvBaseCompStory.fromApi(result);
  }
}
