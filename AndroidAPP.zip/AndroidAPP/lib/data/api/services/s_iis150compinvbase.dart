import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:devices_storage/data/api/services_parameters/s_p_iis150compinvbasecompstory.dart';
import 'package:devices_storage/data/api/service_models/s_m_iis150compinvbasecompstory.dart';

// "На рисунку это поставщик ингридиентов (товаров)"
class ServiceIIS150CompInvBase {
  static const baseurl =
      'http://192.168.171.150/comp/hs/PrettyAPI/V1/deviceHistory?';

  final Dio _dio = Dio(
    BaseOptions(baseUrl: baseurl),
  );

  Future<IIS150CompInvBaseModelCompStory> getDeviceHistoryById(
      ParamIIS150CompInvBaseCompStory body) async {
    final response = await _dio.get(
      '/',
      queryParameters: body.toApi(),
    );

    Map<String, dynamic> map = jsonDecode(response.data);

    return IIS150CompInvBaseModelCompStory.fromApi(map);
  }
}
