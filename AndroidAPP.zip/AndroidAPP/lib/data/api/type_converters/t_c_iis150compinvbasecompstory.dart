import 'package:devices_storage/domain/models/m_compstory.dart';
import 'package:devices_storage/data/api/service_models/s_m_iis150compinvbasecompstory.dart';

// "На рисунке это инструмент приготовления (например блендер)"
class TypeConverterIIS150CompInvBaseCompStory {
  static ModelCompStory fromApi(IIS150CompInvBaseModelCompStory data) {
    return ModelCompStory(
        id: data.id, name: data.name, type: data.type, story: data.story);
  }
}
