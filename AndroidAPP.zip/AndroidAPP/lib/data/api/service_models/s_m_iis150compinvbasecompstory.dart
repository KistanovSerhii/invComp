// "На рисунку это товар поставщика из которого шеф-повар приготовит какое либо блюдо"
class IIS150CompInvBaseModelCompStory {
  String id;
  String name;
  String type;
  List<dynamic> story;

  IIS150CompInvBaseModelCompStory.fromApi(Map<String, dynamic> map)
      : id = map['id'],
        name = map['name'],
        type = map['type'],
        story = map['story'];
}

/*
{
     "id": "000000329",
    "name": "Dell E2418HN",
    "type": "Монитор",
    "story": 
    [
        "count=0; doc=000000594; date=20.08.2022 10:24:37; owner=1. СКЛАД ОТДЕЛА ИТ",
        "count=1; doc=000000588; date=02.08.2022 16:07:57; owner=1. СКЛАД ОТДЕЛА ИТ",
        "count=2; doc=000000587; date=02.08.2022 8:54:38; owner=Плотников Владимир Львович",
        "count=3; doc=000000584; date=27.07.2022 11:34:11; owner=1. СКЛАД ОТДЕЛА ИТ",
        "count=4; doc=000000569; date=15.07.2022 14:06:38; owner=1. СКЛАД ОТДЕЛА ИТ",
        "count=5; doc=; date=; owner=Васильев Георгий Валериевич"
    ]
}
*/