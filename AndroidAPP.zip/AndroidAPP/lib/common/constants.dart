class Constants {
  /*static Image chessIconImg = Image.asset(
    'lib/assets/images/chessboard.png',
    scale: 0.3,
    fit: BoxFit.fitWidth,
  );*/
}
