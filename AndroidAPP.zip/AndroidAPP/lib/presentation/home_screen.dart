import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:devices_storage/domain/state/state_home_screen.dart';

import 'package:localization/localization.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int deviceId = 0;

  // Initial Selected Value
  String dropdownvalue = 'Компьютеры';
  // List of items in our dropdown menu
  var items = [
    'Компьютеры',
    'Монитор',
    'Дополнительное оборудование',
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
//*********************Bluetooth********************* +
    return Scaffold(
        appBar: AppBar(
          title: Text('app-bar'.i18n(),
              style: TextStyle(color: Theme.of(context).primaryColor)),
// *******Командная панель текущей формы******* +
          /*actions: <Widget>[
            IconButton(icon: const Icon(Icons.settings), onPressed: () => {}),
          ],*/
// *******Командная панель текущей формы******* -
        ),
        body: Container(
            color: Theme.of(context).scaffoldBackgroundColor,
            child: SizedBox(
              width: double.infinity, // <-- match_parent
              height: double.infinity, // <-- match-parent
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Flexible(
                        flex: 1,
                        child: Container(),
                      ),
                      Flexible(
                        flex: 4,
                        child:
//****** InputDecoration ****** +++
                            TextField(
                          style:
                              TextStyle(color: Theme.of(context).primaryColor),
                          decoration: InputDecoration(
                              labelText: 'lable-inputDeviceId'.i18n(),
                              labelStyle: TextStyle(
                                  color: Theme.of(context).primaryColor)),
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter
                                .digitsOnly // С таким фильтром могут быть введены только числа
                          ],
                          onChanged: (value) {
                            deviceId = int.parse(value == "" ? "0" : value);
                          },
                        ),
//****** InputDecoration ****** ---
                      ),
                      Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
//****** DropdownButtonHideUnderline ****** +++
                            DropdownButton(
                              dropdownColor:
                                  Theme.of(context).scaffoldBackgroundColor,
                              // Initial Value
                              value: dropdownvalue,
                              // Down Arrow Icon
                              icon: const Icon(Icons.keyboard_arrow_down),
                              // Array list of items
                              items: items.map((String items) {
                                return DropdownMenuItem(
                                  value: items,
                                  child: Text(items,
                                      style: TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                );
                              }).toList(),
                              // After selecting the desired option,it will
                              // change button value to selected value
                              onChanged: (String? newValue) {
                                setState(() {
                                  dropdownvalue = newValue!;
                                });
                              },
                            ),
//****** DropdownButtonHideUnderline ****** ---
                          ]),
                    ],
                  ),

// *******Provider******* +
                  Consumer<StateHomeScreen>(
                      builder: (context, homeStateData, child) {
                    if (homeStateData.isLoading) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (homeStateData.compStory == null) {
                      return Container();
                    }

                    return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                              '${'btn-getHistory'.i18n()}: ${homeStateData.compStory!.id}',
                              style: TextStyle(
                                  color:
                                      Theme.of(context).dialogBackgroundColor))
                        ]);
                  }),
                ],
              ),
            )),
        floatingActionButton: FloatingActionButton(
          child: Icon(Icons.search),
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          foregroundColor: Theme.of(context).primaryColor,
          onPressed: () => {
            Provider.of<StateHomeScreen>(context, listen: false)
                .getDeviceHistoryById(id: deviceId, type: dropdownvalue)
          },
        ));
  }
}

class ListItem {
  int value;
  String name;

  ListItem(this.value, this.name);
}
