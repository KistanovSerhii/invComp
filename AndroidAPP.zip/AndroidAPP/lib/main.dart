import 'package:flutter/material.dart';
import 'package:devices_storage/internal/application.dart';

import 'package:adaptive_theme/adaptive_theme.dart';

void main() async {
//***********************Binding sqf ini*********************** +
  WidgetsFlutterBinding.ensureInitialized();
//************************bind sqf init************************ -

//*********************Get last Theme mode********************* +
  WidgetsFlutterBinding.ensureInitialized();
  final savedThemeMode = await AdaptiveTheme.getThemeMode();
//*********************Get last Theme mode********************* -
  runApp(Application(savedThemeMode: savedThemeMode));
}
