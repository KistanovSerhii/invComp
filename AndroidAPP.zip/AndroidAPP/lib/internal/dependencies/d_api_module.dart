import 'package:devices_storage/data/api/a_iis150compinvbase.dart';
import 'package:devices_storage/data/api/services/s_iis150compinvbase.dart';

class DependencyModuleApi {
  static ApiIIS150CompInvBase? _iis150CompInvBaseApi;

  static ApiIIS150CompInvBase iis150CompInvBaseApi() {
    // if ref == null return new or current ref
    return _iis150CompInvBaseApi ??=
        ApiIIS150CompInvBase(ServiceIIS150CompInvBase());
  }
}
