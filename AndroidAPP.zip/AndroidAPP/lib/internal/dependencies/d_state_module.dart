import 'package:devices_storage/internal/dependencies/d_repo_module.dart';
import 'package:devices_storage/domain/state/state_home_screen.dart';

class DependencyModuleState {
  static StateHomeScreen homeState() {
    return StateHomeScreen(
        compInvBase1C: DependencyModuleRepository.compInvBase1CSource());
  }
}
