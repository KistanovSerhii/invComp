import 'package:devices_storage/internal/dependencies/d_api_module.dart';
import 'package:devices_storage/domain/contracts/c_compinvbase1csource.dart';
import 'package:devices_storage/data/repositories/r_iis150compinvbase.dart';

class DependencyModuleRepository {
  static CompInvBase1CSourceContract? _compInvBase1CRepo;

  static CompInvBase1CSourceContract compInvBase1CSource() {
    // if ref == null return new or current ref
    return _compInvBase1CRepo ??=
        RepositoryIIS150CompInvBase(DependencyModuleApi.iis150CompInvBaseApi());
  }
}
